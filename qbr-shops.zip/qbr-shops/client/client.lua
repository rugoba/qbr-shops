
function SET_PED_RELATIONSHIP_GROUP_HASH ( iVar0, iParam0 )
    return Citizen.InvokeNative( 0xC80A74AC829DDD92, iVar0, _GET_DEFAULT_RELATIONSHIP_GROUP_HASH( iParam0 ) )
end

function _GET_DEFAULT_RELATIONSHIP_GROUP_HASH ( iParam0 )
    return Citizen.InvokeNative( 0x3CC4A718C258BDD0 , iParam0 );
end

Citizen.CreateThread(function()
for store, v in pairs(Config.Locations) do
    while not HasModelLoaded( GetHashKey(v.model) ) do
        Wait(500)
        RequestModel(v.model)
    end
    local npc = CreatePed(GetHashKey(v.model), v.coords, v.Heading , false, false, 0, 0)
    while not DoesEntityExist(npc) do
      Wait(300)
    end
  
    Citizen.InvokeNative(0x9587913B9E772D29, npc, true)
    Citizen.InvokeNative(0x283978A15512B2FE, npc, true)
    FreezeEntityPosition(npc, true)
    SetEntityCanBeDamaged(npc, false)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    Citizen.InvokeNative(0xC80A74AC829DDD92, npc, GetPedRelationshipGroupHash(npc))
    Citizen.InvokeNative(0xBF25EB89375A37AD, 1, GetPedRelationshipGroupHash(npc), `PLAYER`)
    TaskStandStill(npc, -1)

    exports['qbr-target']:AddCircleZone(v.name, v.coords, 3.0, {
        name = v.name, 
        debugPoly = false, 
      }, {
        options = { 
          {
            type = "client",
          
            icon = "fas fa-donate",
            label = "Open "..v.name,
            targeticon = "fas fa-eye",
            action = function(entity) 
                TriggerEvent('qbr-shops:openshop',v.products, v.name)
            end
        
           }
        },
        distance = 3.0, 
      })
    if v.showblip == true then
        local StoreBlip = N_0x554d9d53f696d002(1664425300, v.coords)
        if v.products == "normal" then
            SetBlipSprite(StoreBlip, 1475879922, 52)
            SetBlipScale(StoreBlip, 0.2)
            Citizen.InvokeNative(0x9CB1A1623062F402, StoreBlip, v.name)
        elseif v.products == "weapons" then
            SetBlipSprite(StoreBlip, -145868367, 1)
            SetBlipScale(StoreBlip, 0.2)
            Citizen.InvokeNative(0x9CB1A1623062F402, StoreBlip, v.name)
        elseif v.products == "saloon" then
            SetBlipSprite(StoreBlip, 1879260108, 1)
            SetBlipScale(StoreBlip, 0.2)
            Citizen.InvokeNative(0x9CB1A1623062F402, StoreBlip, v.name)
        elseif v.products == "farmseed" then
            SetBlipSprite(StoreBlip, 1475879922, 1)
            SetBlipScale(StoreBlip, 0.2)
            Citizen.InvokeNative(0x9CB1A1623062F402, StoreBlip, v.name)
        end
    end
end

end)

RegisterNetEvent('qbr-shops:openshop')
AddEventHandler('qbr-shops:openshop', function(shopType, shopName)
    local type = shopType
    local shop = shopName
    local ShopItems = {}
    ShopItems.items = {}
    exports['qbr-core']:TriggerCallback('qbr-shops:server:getLicenseStatus', function(result)
        ShopItems.label = shop
        if type == "weapon" then
            if result then
                ShopItems.items =  Config.Products[type]
            else
                for i = 1, #Config.Products[type] do
                    if not Config.Products[type][i].requiresLicense then
                        table.insert(ShopItems.items, Config.Products[type][i])
                    end
                end
            end
        else
            ShopItems.items = Config.Products[type]
        end
        ShopItems.slots = 30
        TriggerServerEvent("inventory:server:OpenInventory", "shop", "Itemshop_"..type, ShopItems) --Review later for visual correction
    end)
end)

RegisterNetEvent('qbr-shops:client:UpdateShop')
AddEventHandler('qbr-shops:client:UpdateShop', function(shopType, itemData, amount)
    TriggerServerEvent('qbr-shops:server:UpdateShopItems', shopType, itemData, amount)
end)

RegisterNetEvent('qbr-shops:client:SetShopItems')
AddEventHandler('qbr-shops:client:SetShopItems', function(shopType, shopProducts)
    Config.Products[shopType] = shopProducts
end)

RegisterNetEvent('qbr-shops:client:RestockShopItems')
AddEventHandler('qbr-shops:client:RestockShopItems', function(shopType, amount)
    print('RESTOCK FUNCTION')
    print(shopType)
    print(amount)
    if Config.Products[shopType] ~= nil then
        for k, v in pairs(Config.Products[shopType]) do
            Config.Products[shopType][k].amount = Config.Products[shopType][k].amount + amount
        end
    end
end)


